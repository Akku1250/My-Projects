﻿namespace AreaAndVolume
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUnit1 = new System.Windows.Forms.Label();
            this.txtboxValue1 = new System.Windows.Forms.TextBox();
            this.txtboxValue2 = new System.Windows.Forms.TextBox();
            this.lblUnit2 = new System.Windows.Forms.Label();
            this.txtboxValue3 = new System.Windows.Forms.TextBox();
            this.lblUnit3 = new System.Windows.Forms.Label();
            this.cmbboxType = new System.Windows.Forms.ComboBox();
            this.cmbboxShape = new System.Windows.Forms.ComboBox();
            this.lblType = new System.Windows.Forms.Label();
            this.lblShape = new System.Windows.Forms.Label();
            this.btnCompute = new System.Windows.Forms.Button();
            this.lblRes = new System.Windows.Forms.Label();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.grpBoxValue = new System.Windows.Forms.GroupBox();
            this.grpBoxValue.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblUnit1
            // 
            this.lblUnit1.AutoSize = true;
            this.lblUnit1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnit1.Location = new System.Drawing.Point(13, 37);
            this.lblUnit1.Name = "lblUnit1";
            this.lblUnit1.Size = new System.Drawing.Size(108, 25);
            this.lblUnit1.TabIndex = 0;
            this.lblUnit1.Text = "ValueUnit1";
            // 
            // txtboxValue1
            // 
            this.txtboxValue1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxValue1.Location = new System.Drawing.Point(166, 34);
            this.txtboxValue1.Name = "txtboxValue1";
            this.txtboxValue1.Size = new System.Drawing.Size(185, 30);
            this.txtboxValue1.TabIndex = 1;
            this.txtboxValue1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtboxValue1_KeyPress);
            // 
            // txtboxValue2
            // 
            this.txtboxValue2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxValue2.Location = new System.Drawing.Point(166, 68);
            this.txtboxValue2.Name = "txtboxValue2";
            this.txtboxValue2.Size = new System.Drawing.Size(185, 30);
            this.txtboxValue2.TabIndex = 3;
            this.txtboxValue2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtboxValue2_KeyPress);
            // 
            // lblUnit2
            // 
            this.lblUnit2.AutoSize = true;
            this.lblUnit2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnit2.Location = new System.Drawing.Point(13, 71);
            this.lblUnit2.Name = "lblUnit2";
            this.lblUnit2.Size = new System.Drawing.Size(108, 25);
            this.lblUnit2.TabIndex = 2;
            this.lblUnit2.Text = "ValueUnit2";
            // 
            // txtboxValue3
            // 
            this.txtboxValue3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxValue3.Location = new System.Drawing.Point(166, 102);
            this.txtboxValue3.Name = "txtboxValue3";
            this.txtboxValue3.Size = new System.Drawing.Size(185, 30);
            this.txtboxValue3.TabIndex = 5;
            this.txtboxValue3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtboxValue3_KeyPress);
            // 
            // lblUnit3
            // 
            this.lblUnit3.AutoSize = true;
            this.lblUnit3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnit3.Location = new System.Drawing.Point(13, 107);
            this.lblUnit3.Name = "lblUnit3";
            this.lblUnit3.Size = new System.Drawing.Size(108, 25);
            this.lblUnit3.TabIndex = 4;
            this.lblUnit3.Text = "ValueUnit3";
            this.lblUnit3.Click += new System.EventHandler(this.lblUnit3_Click);
            // 
            // cmbboxType
            // 
            this.cmbboxType.FormattingEnabled = true;
            this.cmbboxType.Items.AddRange(new object[] {
            "Area",
            "Volume"});
            this.cmbboxType.Location = new System.Drawing.Point(76, 215);
            this.cmbboxType.Name = "cmbboxType";
            this.cmbboxType.Size = new System.Drawing.Size(121, 24);
            this.cmbboxType.TabIndex = 6;
            this.cmbboxType.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cmbboxShape
            // 
            this.cmbboxShape.FormattingEnabled = true;
            this.cmbboxShape.Items.AddRange(new object[] {
            "Square",
            "Rectangle",
            "Circle",
            "Cylinder",
            "Triangle"});
            this.cmbboxShape.Location = new System.Drawing.Point(312, 215);
            this.cmbboxShape.Name = "cmbboxShape";
            this.cmbboxShape.Size = new System.Drawing.Size(121, 24);
            this.cmbboxShape.TabIndex = 7;
            this.cmbboxShape.SelectedValueChanged += new System.EventHandler(this.cmbboxShape_SelectedValueChanged);
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(119, 192);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(40, 17);
            this.lblType.TabIndex = 8;
            this.lblType.Text = "Type";
            // 
            // lblShape
            // 
            this.lblShape.AutoSize = true;
            this.lblShape.Location = new System.Drawing.Point(350, 192);
            this.lblShape.Name = "lblShape";
            this.lblShape.Size = new System.Drawing.Size(49, 17);
            this.lblShape.TabIndex = 9;
            this.lblShape.Text = "Shape";
            // 
            // btnCompute
            // 
            this.btnCompute.BackColor = System.Drawing.Color.SpringGreen;
            this.btnCompute.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompute.ForeColor = System.Drawing.Color.White;
            this.btnCompute.Location = new System.Drawing.Point(76, 269);
            this.btnCompute.Name = "btnCompute";
            this.btnCompute.Size = new System.Drawing.Size(139, 51);
            this.btnCompute.TabIndex = 10;
            this.btnCompute.Text = "Calculate";
            this.btnCompute.UseVisualStyleBackColor = false;
            this.btnCompute.Click += new System.EventHandler(this.btnCompute_Click);
            // 
            // lblRes
            // 
            this.lblRes.AutoSize = true;
            this.lblRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRes.Location = new System.Drawing.Point(247, 285);
            this.lblRes.Name = "lblRes";
            this.lblRes.Size = new System.Drawing.Size(89, 25);
            this.lblRes.TabIndex = 11;
            this.lblRes.Text = "Answer: ";
            // 
            // lblAnswer
            // 
            this.lblAnswer.AutoSize = true;
            this.lblAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnswer.Location = new System.Drawing.Point(350, 285);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(19, 25);
            this.lblAnswer.TabIndex = 12;
            this.lblAnswer.Text = "-";
            // 
            // grpBoxValue
            // 
            this.grpBoxValue.Controls.Add(this.lblUnit1);
            this.grpBoxValue.Controls.Add(this.txtboxValue1);
            this.grpBoxValue.Controls.Add(this.txtboxValue2);
            this.grpBoxValue.Controls.Add(this.txtboxValue3);
            this.grpBoxValue.Controls.Add(this.lblUnit2);
            this.grpBoxValue.Controls.Add(this.lblUnit3);
            this.grpBoxValue.Location = new System.Drawing.Point(76, 30);
            this.grpBoxValue.Name = "grpBoxValue";
            this.grpBoxValue.Size = new System.Drawing.Size(357, 159);
            this.grpBoxValue.TabIndex = 13;
            this.grpBoxValue.TabStop = false;
            this.grpBoxValue.Text = "Enter Values:";
            this.grpBoxValue.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(496, 376);
            this.Controls.Add(this.grpBoxValue);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.lblRes);
            this.Controls.Add(this.btnCompute);
            this.Controls.Add(this.lblShape);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.cmbboxShape);
            this.Controls.Add(this.cmbboxType);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.grpBoxValue.ResumeLayout(false);
            this.grpBoxValue.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lblUnit1;
        private System.Windows.Forms.TextBox txtboxValue1;
        private System.Windows.Forms.TextBox txtboxValue2;
        private System.Windows.Forms.Label lblUnit2;
        private System.Windows.Forms.TextBox txtboxValue3;
        private System.Windows.Forms.Label lblUnit3;
        private System.Windows.Forms.ComboBox cmbboxType;
        private System.Windows.Forms.ComboBox cmbboxShape;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblShape;
        private System.Windows.Forms.Button btnCompute;
        private System.Windows.Forms.Label lblRes;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.GroupBox grpBoxValue;
    }
}

