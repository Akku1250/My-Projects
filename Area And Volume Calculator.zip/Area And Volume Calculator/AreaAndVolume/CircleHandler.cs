﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaAndVolume
{
    class CircleHandler
    {
        private double radius;

        public double getRadius()
        {
            return radius;
        }

        public void setRadius(double radiusv)
        {
            radius = radiusv;
        }

        public double AreaofCircle()
        {
            double answer = Math.Round((Math.PI * Math.Pow(getRadius(), 2)), 2);
            return answer;
        }

        public double VolumeofCircle()
        {
            double part1 = (4 / 3.0) * Math.PI * Math.Pow(getRadius(), 3);
            double answer = Math.Round((part1), 2);
            return answer;
        }
    }

}
