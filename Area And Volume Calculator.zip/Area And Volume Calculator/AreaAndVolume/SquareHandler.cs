﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaAndVolume
{
    class SquareHandler
    {
        private double SquareValue;

        public double getSquareValue()
        {
            return SquareValue;
        }

        public void setSetSquareValue(double squareValue)
        {
            SquareValue = squareValue;
        }
        public double AreaofSquare()
        {
            double answer = Math.Round(Math.Pow(getSquareValue(), 2),2);
            return  answer;
        }

        public double VolumeofSquare()
        {
            double answer = Math.Round(Math.Pow(getSquareValue(), 4), 2);
            return answer;
        }


    }
}
