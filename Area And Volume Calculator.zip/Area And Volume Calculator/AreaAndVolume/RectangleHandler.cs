﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaAndVolume
{
    class RectangleHandler
    {
        private double length;
        private double height;
        private double width;

        public double getLengthValue()
        {
            return length;
        }

        public void setLengthValue(double lengthv)
        {
            length = lengthv;
        }

        public double getHeightValue()
        {
            return height;
        }

        public void setHeightValue(double heightv)
        {
            height = heightv;
        }

        public double getWidthtValue()
        {
            return width;
        }

        public void setWidthValue(double widthv)
        {
            width = widthv;
        }

        public double AreaofRectangle()
        {
            double answer = Math.Round(getLengthValue()*getWidthtValue(), 2);
            return answer;
        }

        public double VolumeofRectangle()
        {
            double answer = Math.Round(getHeightValue() * getLengthValue() * getWidthtValue(), 2);
            return answer;
        }


    }
}
