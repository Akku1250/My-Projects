﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AreaAndVolume
{
    public partial class Form1 : Form
    {
        SquareHandler square = new SquareHandler();
        RectangleHandler rectangle = new RectangleHandler();
        CircleHandler circle = new CircleHandler();
        CylinderHandler cylinder = new CylinderHandler();
        TriangleHandler triangle = new TriangleHandler();

        public Form1()
        {
            InitializeComponent();
            clearall();

        }

        private void clearall()
        {
            txtboxValue1.Visible = false;
            txtboxValue2.Visible = false;
            txtboxValue3.Visible = false;
            lblUnit1.Visible = false;
            lblUnit2.Visible = false;
            lblUnit3.Visible = false;
        }

        public void itemVisibility()
        {

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblUnit3_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            




        }

        private void cmbboxShape_SelectedValueChanged(object sender, EventArgs e)
        {
            string selectedShapeItem = cmbboxShape.SelectedItem.ToString();
            string selectedTypeItem = cmbboxType.SelectedItem.ToString();

            if (selectedShapeItem == "Square" && selectedTypeItem == "Area")
            {
                txtboxValue2.Visible = true;
                txtboxValue2.Clear();
                lblUnit2.Visible = true;
                lblUnit2.Text = "a";
                lblAnswer.Text = "";

                txtboxValue1.Visible = false;
                lblUnit1.Visible = false;
                txtboxValue3.Visible = false;
                lblUnit3.Visible = false;
            }
            else if (selectedShapeItem == "Rectangle" && selectedTypeItem == "Area")
            {
                txtboxValue1.Visible = true;
                txtboxValue1.Clear();
                txtboxValue2.Visible = true;
                txtboxValue2.Clear();
                lblUnit1.Visible = true;
                lblUnit1.Text = "Length";
                lblUnit2.Visible = true;
                lblUnit2.Text = "Width";
                lblAnswer.Text = "";

                txtboxValue3.Visible = false;
                lblUnit3.Visible = false;

            }
            else if (selectedShapeItem == "Circle" && selectedTypeItem == "Area")
            {
                txtboxValue2.Visible = true;
                txtboxValue2.Clear();
                lblUnit2.Visible = true;
                lblUnit2.Text = "Radius";
                lblAnswer.Text = "";

                txtboxValue1.Visible = false;
                lblUnit1.Visible = false;
                txtboxValue3.Visible = false;
                lblUnit3.Visible = false; ;
            }
            else if (selectedShapeItem == "Cylinder" && selectedTypeItem == "Area")
            {
                txtboxValue1.Visible = true;
                txtboxValue1.Clear();
                txtboxValue2.Visible = true;
                txtboxValue2.Clear();
                lblUnit1.Visible = true;
                lblUnit1.Text =  "Height";
                lblUnit2.Visible = true;
                lblUnit2.Text = "Radius";
                lblAnswer.Text = "";

                txtboxValue3.Visible = false;
                lblUnit3.Visible = false;
            }
            else if (selectedShapeItem == "Triangle" && selectedTypeItem == "Area")
            {
                txtboxValue1.Visible = true;
                txtboxValue1.Clear();
                txtboxValue2.Visible = true;
                txtboxValue2.Clear();
                lblUnit1.Visible = true;
                lblUnit1.Text = "Base";
                lblUnit2.Visible = true;
                lblUnit2.Text = "Height";
                lblAnswer.Text = "";

                txtboxValue3.Visible = false;
                lblUnit3.Visible = false;
            }
            else if (selectedShapeItem == "Square" && selectedTypeItem == "Volume")
            {
                txtboxValue2.Visible = true;
                txtboxValue2.Clear();
                lblUnit2.Visible = true;
                lblUnit2.Text = "a";
                lblAnswer.Text = "";

                txtboxValue1.Visible = false;
                lblUnit1.Visible = false;
                txtboxValue3.Visible = false;
                lblUnit3.Visible = false;

            }
            else if (selectedShapeItem == "Rectangle" && selectedTypeItem == "Volume")
            {
                txtboxValue1.Visible = true;
                txtboxValue1.Clear();
                txtboxValue2.Visible = true;
                txtboxValue2.Clear();
                txtboxValue3.Visible = true;
                txtboxValue3.Clear();
                lblUnit1.Visible = true;
                lblUnit2.Visible = true;
                lblUnit3.Visible = true;
                lblAnswer.Text = "";
                lblUnit1.Text = "Length";
                lblUnit2.Text = "Width";
                lblUnit3.Text = "Height";
            }
            else if (selectedShapeItem == "Circle" && selectedTypeItem == "Volume")
            {
                txtboxValue2.Visible = true;
                txtboxValue2.Clear();
                lblUnit2.Visible = true;
                lblUnit2.Text = "Radius";
                lblAnswer.Text = "";

                txtboxValue1.Visible = false;
                lblUnit1.Visible = false;
                txtboxValue3.Visible = false;
                lblUnit3.Visible = false;
            }
            else if (selectedShapeItem == "Cylinder" && selectedTypeItem == "Volume")
            {

                txtboxValue1.Visible = true;
                txtboxValue1.Clear();
                txtboxValue2.Visible = true;
                txtboxValue2.Clear();
                lblUnit1.Visible = true;
                lblUnit1.Text = "Height";
                lblUnit2.Visible = true;
                lblUnit2.Text = "Radius";
                lblAnswer.Text = "";

                txtboxValue3.Visible = false;
                lblUnit3.Visible = false;

            }
            else
            {
                clearall();
            }
            
        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            string selectedShapeItem = cmbboxShape.SelectedItem.ToString();
            string selectedTypeItem = cmbboxType.SelectedItem.ToString();

            if (selectedShapeItem == "Square" && selectedTypeItem == "Area")
            {
                square.setSetSquareValue(Double.Parse(txtboxValue2.Text));
                lblAnswer.Text = square.AreaofSquare().ToString();
            }
            else if (selectedShapeItem == "Rectangle" && selectedTypeItem == "Area")
            {
                rectangle.setLengthValue(Double.Parse(txtboxValue1.Text));
                rectangle.setWidthValue(Double.Parse(txtboxValue2.Text));
                lblAnswer.Text = rectangle.AreaofRectangle().ToString();
               
            }
            else if (selectedShapeItem == "Circle" && selectedTypeItem == "Area")
            {
                circle.setRadius(Double.Parse(txtboxValue2.Text));
                lblAnswer.Text = circle.AreaofCircle().ToString();

            }
            else if (selectedShapeItem == "Cylinder" && selectedTypeItem == "Area")
            {
            
                cylinder.setHeight(Double.Parse(txtboxValue1.Text));
                cylinder.setRadius(Double.Parse(txtboxValue2.Text));
                lblAnswer.Text = cylinder.AreaofCylinder().ToString();

            }
            else if (selectedShapeItem == "Triangle" && selectedTypeItem == "Area")
            {
                triangle.setTriangle_Base(Double.Parse(txtboxValue1.Text));
                triangle.setTriangle_Height(Double.Parse(txtboxValue2.Text));
                lblAnswer.Text = triangle.AreaofTriangle().ToString();

            }
            else if (selectedShapeItem == "Square" && selectedTypeItem == "Volume")
            {
                square.setSetSquareValue(Double.Parse(txtboxValue2.Text));
                lblAnswer.Text = square.VolumeofSquare().ToString();
            }
            else if (selectedShapeItem == "Rectangle" && selectedTypeItem == "Volume")
            {
                rectangle.setLengthValue(Double.Parse(txtboxValue1.Text));
                rectangle.setWidthValue(Double.Parse(txtboxValue2.Text));
                rectangle.setHeightValue(Double.Parse(txtboxValue3.Text));
                lblAnswer.Text = rectangle.VolumeofRectangle().ToString();
            }
            else if (selectedShapeItem == "Circle" && selectedTypeItem == "Volume")
            {
               
                circle.setRadius(Double.Parse(txtboxValue2.Text));
                lblAnswer.Text = circle.VolumeofCircle().ToString();

            }
            else if (selectedShapeItem == "Cylinder" && selectedTypeItem == "Volume")
            {
                cylinder.setHeight(Double.Parse(txtboxValue1.Text));
                cylinder.setRadius(Double.Parse(txtboxValue2.Text));
                lblAnswer.Text = cylinder.VolumeofCylinder().ToString();

            }
            else
            {
                clearall();
            }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46 && ch != ',')
            {
                e.Handled = true;
            }
        }

        private void txtboxValue1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46 && ch != ',')
            {
                e.Handled = true;
            }
        }

        private void txtboxValue2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46 && ch != ',')
            {
                e.Handled = true;
            }
        }

        private void txtboxValue3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46 && ch != ',')
            {
                e.Handled = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
