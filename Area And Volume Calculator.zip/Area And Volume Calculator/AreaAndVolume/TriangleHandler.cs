﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaAndVolume
{
    class TriangleHandler
    {
        private double Triangle_Base;
        private double Triangle_Height;

        public double getTriangle_Base()
        {
            return Triangle_Base;
        }

        public double getTriangle_Height()
        {
            return Triangle_Height;
        }

        public void setTriangle_Base(double triangle_base)
        {
            this.Triangle_Base = triangle_base;
        }

        public void setTriangle_Height(double triangle_height)
        {
            this.Triangle_Height = triangle_height;
        }

        public double AreaofTriangle()
        {
            double answer = Math.Round(((1/2.0) * getTriangle_Base()* getTriangle_Height()),2);
            return answer;
        }

    }
}
