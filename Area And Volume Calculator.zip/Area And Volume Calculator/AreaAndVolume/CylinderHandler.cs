﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaAndVolume
{
    class CylinderHandler : CircleHandler

    {
        private double height;

        public double getHeight()
        {
            return height;
        }

        public void setHeight(double heightv)
        {
            height = heightv;
        }
        public double AreaofCylinder()
        {
            //A = 2πrh + 2πr2
            double part1 = 2 * Math.PI* getRadius() * getHeight();
            double part2 = 2 * Math.PI * Math.Pow(getRadius(), 2);

            //double q = 2 * Math.PI * getRadius() * getHeight() + 2 * Math.PI * Math.Pow(getRadius(),2) ;
            double answer = (Math.Round((part1+part2), 2));
            return answer;
        }

        public double VolumeofCylinder()
        {
            double answer = Math.Round((Math.PI * Math.Pow(getRadius(),2) * getHeight()), 2);
            return answer;
        }
    }
}
