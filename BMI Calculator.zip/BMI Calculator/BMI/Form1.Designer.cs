﻿namespace BMI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeight = new System.Windows.Forms.Label();
            this.txtboxHeight = new System.Windows.Forms.TextBox();
            this.txtboxWeight = new System.Windows.Forms.TextBox();
            this.lblWeight = new System.Windows.Forms.Label();
            this.lblBMI = new System.Windows.Forms.Label();
            this.lblBMIResult = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCommentResult = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblHeading = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeight.Location = new System.Drawing.Point(22, 148);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(165, 25);
            this.lblHeight.TabIndex = 0;
            this.lblHeight.Text = "Enter Height (m): ";
            this.lblHeight.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtboxHeight
            // 
            this.txtboxHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxHeight.ForeColor = System.Drawing.Color.Black;
            this.txtboxHeight.Location = new System.Drawing.Point(227, 145);
            this.txtboxHeight.Name = "txtboxHeight";
            this.txtboxHeight.Size = new System.Drawing.Size(202, 30);
            this.txtboxHeight.TabIndex = 1;
            this.txtboxHeight.TextChanged += new System.EventHandler(this.txtboxHeight_TextChanged);
            this.txtboxHeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtboxHeight_KeyPress);
            // 
            // txtboxWeight
            // 
            this.txtboxWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxWeight.ForeColor = System.Drawing.Color.Black;
            this.txtboxWeight.Location = new System.Drawing.Point(227, 99);
            this.txtboxWeight.Name = "txtboxWeight";
            this.txtboxWeight.Size = new System.Drawing.Size(202, 30);
            this.txtboxWeight.TabIndex = 3;
            this.txtboxWeight.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.txtboxWeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtboxWeight_KeyPress);
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWeight.Location = new System.Drawing.Point(22, 104);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(176, 25);
            this.lblWeight.TabIndex = 2;
            this.lblWeight.Text = "Enter Weight (kg): ";
            this.lblWeight.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lblBMI
            // 
            this.lblBMI.AutoSize = true;
            this.lblBMI.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBMI.Location = new System.Drawing.Point(26, 208);
            this.lblBMI.Name = "lblBMI";
            this.lblBMI.Size = new System.Drawing.Size(104, 25);
            this.lblBMI.TabIndex = 4;
            this.lblBMI.Text = "Your BMI: ";
            // 
            // lblBMIResult
            // 
            this.lblBMIResult.AutoSize = true;
            this.lblBMIResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBMIResult.Location = new System.Drawing.Point(222, 208);
            this.lblBMIResult.Name = "lblBMIResult";
            this.lblBMIResult.Size = new System.Drawing.Size(19, 25);
            this.lblBMIResult.TabIndex = 5;
            this.lblBMIResult.Text = "-";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 246);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "Comment: ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblCommentResult
            // 
            this.lblCommentResult.AutoSize = true;
            this.lblCommentResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCommentResult.Location = new System.Drawing.Point(222, 246);
            this.lblCommentResult.Name = "lblCommentResult";
            this.lblCommentResult.Size = new System.Drawing.Size(19, 25);
            this.lblCommentResult.TabIndex = 7;
            this.lblCommentResult.Text = "-";
            this.lblCommentResult.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.ForeColor = System.Drawing.Color.White;
            this.btnCalculate.Location = new System.Drawing.Point(236, 296);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(164, 52);
            this.btnCalculate.TabIndex = 8;
            this.btnCalculate.Text = "Compute BMI";
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Segoe Script", 22.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(175, 24);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(101, 60);
            this.lblHeading.TabIndex = 9;
            this.lblHeading.Text = "BMI";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 410);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblCommentResult);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblBMIResult);
            this.Controls.Add(this.lblBMI);
            this.Controls.Add(this.txtboxWeight);
            this.Controls.Add(this.lblWeight);
            this.Controls.Add(this.txtboxHeight);
            this.Controls.Add(this.lblHeight);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BMI";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.TextBox txtboxHeight;
        private System.Windows.Forms.TextBox txtboxWeight;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblBMI;
        private System.Windows.Forms.Label lblBMIResult;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCommentResult;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblHeading;
    }
}

