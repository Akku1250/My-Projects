﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        BMIHandler bmi = new BMIHandler();

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           

            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtboxHeight_TextChanged(object sender, EventArgs e)
        {
          

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            bmi.SetPersonWeight(Double.Parse(txtboxWeight.Text));
            bmi.SetPersonHeight(Double.Parse(txtboxHeight.Text));
            lblBMIResult.Text = bmi.BMICalculator().ToString();
            //MessageBox.Show(bmi.GetPersonHeight().ToString());
            //MessageBox.Show(bmi.GetPersonWeight().ToString());

            lblCommentResult.Text = bmi.DisplayComment(bmi.BMICalculator());
        }

        private void txtboxHeight_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if(!Char.IsDigit(ch) && ch != 8 && ch != 46 && ch != ',')
            {
                e.Handled = true;
            }
        }

        private void txtboxWeight_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46 && ch != ',')
            {
                e.Handled = true;
            }
        }
    }
}
