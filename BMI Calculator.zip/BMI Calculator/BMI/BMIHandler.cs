﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMI
{
    class BMIHandler
    {
        private double PersonHeight;
        private double PersonWeight;

        public void SetPersonHeight(double personHeight)
        {
            PersonHeight = personHeight;
        }

        public double GetPersonHeight()
        {
            return PersonHeight;
        }

        public void SetPersonWeight(double personWeight)
        {
            PersonWeight = personWeight;
        }

        public double GetPersonWeight()
        {
            return PersonWeight;
        }

        public double BMICalculator()
        {
            double results = (GetPersonWeight() / Math.Pow(GetPersonHeight(),2));
            return Math.Round(results,2);

        }
        public String DisplayComment(double BmiResult)
        {
            String message = " ";
            if (BmiResult < 18.5)
            {
                message = "Underweight";

            }
            else if (BmiResult >= 18.5 && BmiResult <= 24.9)
            {
                message = "Normal Weight";

            }
            else if (BmiResult >= 25 && BmiResult <= 29.9)
            {
                message = "Overweight";
            }
            else
            {
                message = "Obesity";
            }
            return message;

        }
    }
}
